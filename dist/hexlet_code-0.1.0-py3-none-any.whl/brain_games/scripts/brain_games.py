
#!/usr/bin/env python3

def print_hello():
    print('Welcome to Brain Games!')

def main():
    print_hello()

if __name__ == '__main__':
    main()

